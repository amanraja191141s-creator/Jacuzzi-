# SA Calculator v1.97.9-v97.9 — Error preview row geometry audit

## Recording evidence
Reviewed `Screenrecording_20261114_190708.mp4` (38.07 seconds, 373 frames, 9.80 fps). The recording shows the live preview for `9^9999` changing to `Error`, then returning to a numeric scientific preview when the expression is edited. The Error label appears vertically displaced relative to the successful preview lane.

## Root cause confirmed in v97.7 source
The stylesheet had conflicting error-only row sizing:
- Normal `.calc-preview-row` used `min-height: 32px`.
- Live error mode forced `min-height: clamp(48px, 9vh, 76px)`.
- A separate committed-error rule forced `min-height: 30px`.
- Error typography also overrode the preview line metrics (`line-height: 1.12` and negative letter spacing).

Because the calculator display is a vertical flex layout, changing a child row's height/basis changes the vertical space consumed and shifts the visible preview lane. The previous 48–76px override was therefore the direct cause of the observed row movement.

## Correction in v97.9
- Unify the normal preview and error preview row at a fixed `32px` flex basis, min-height, height and max-height.
- Center content vertically in that same lane.
- Remove error-only line-height and letter-spacing changes; preserve the measured preview font size.
- Keep only the semantic error color and stronger weight distinct.
- Apply the same geometry to live and committed error preview states.
- Keep the 25px horizontal inset for error rows.
- Update the service-worker cache namespace so clients fetch the corrected CSS.

## Regression coverage
- Exact 32px lane geometry for successful and error preview.
- Live and committed error selectors share the same row sizing.
- Error typography no longer changes line-height or letter spacing.
- 25px horizontal inset retained.
- Existing calculator, memory, scientific-entry, scientific-result continuation, currency, localization, server-security and release tests retained.

## Verification scope
Automated tests, source syntax checks, ZIP integrity, static HTML/CSS checks and local HTTP smoke test are run for this release. Physical Android WebView rendering/touch validation remains a separate device-level check and is not claimed as completed.
