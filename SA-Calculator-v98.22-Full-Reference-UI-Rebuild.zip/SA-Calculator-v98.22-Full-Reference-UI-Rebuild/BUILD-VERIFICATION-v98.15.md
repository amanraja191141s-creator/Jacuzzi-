# SA Calculator v98.15 — Source and workflow verification

## Release contents
- Source release: `SA-Calculator-v98.15-Premium-Tools-Complete-Redesign.zip`
- GitHub Actions workflow: `main-v98.15-premium-tools.yml`
- Application package version: `1.98.15-v98.15`

## Design scope
The v98.15 stylesheet applies the new deep-navy, electric-blue, cyan and restrained-gold visual system across all 18 registered destinations: Calculator, Currency Converter, Units, Discount, Percent, Sales Tax, Body Metrics, Date, Fuel Cost, Fuel Efficiency, Grade Average, Number Base, Loan/EMI, Savings, Tip, Unit Price, World Time and Settings. Shared overlays, drawer, history, currency picker, scientific keypad and settings surfaces are also covered.

The old CSS structural rules remain underneath where needed for existing DOM/layout hooks and runtime compatibility; the old light/grey visual appearance is overridden by the v98.15 visual system. Calculator formulas, currency calculations, routing, field order, data persistence and event handlers were not intentionally rewritten in this design pass.

## Checks run in this environment
- `npm run build:web`: passed.
- `npm test`: 160 passed, 0 failed, 0 skipped.
- `node --check assets/js/app.js`: passed.
- `node --check scripts/prepare-android-web.mjs`: passed.
- `node --check scripts/patch-android-native.mjs`: passed.
- Root and generated `www/` HTML/CSS/JS bundle parity: passed.
- 18 registered destinations plus viewport shell: verified.
- PWA 192px/512px icon declarations and Android launcher icon resources: verified.
- ZIP integrity: passed.
- GitHub Actions YAML syntax: passed.
- Workflow release gate requires exact package version `1.98.15-v98.15`.

## Not claimed
This is source-level verification only. A cloud GitHub Actions run, Android Gradle APK build, APK install, and visual QA on a physical Vivo/Android device have not been run in this environment. Verify status/navigation bar insets, keyboard overlap, small-screen/landscape layouts, icon/splash appearance, all tool interactions, and live/offline currency behaviour on-device before calling the APK fully verified.
