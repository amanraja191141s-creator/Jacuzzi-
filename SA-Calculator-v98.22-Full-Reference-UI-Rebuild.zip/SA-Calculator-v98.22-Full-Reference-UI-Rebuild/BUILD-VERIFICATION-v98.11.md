# SA Calculator v98.11 — GitHub Actions workflow and regression-test repair

## Confirmed issue addressed
The project ZIP previously carried an embedded `.github/workflows/android-apk.yml` that was not synchronized with the repository-level `main.yml` workflow. It still contained a fixed v98.9 archive filename and a different source-locator implementation. The regression test inspected the embedded workflow, while the user was editing the repository-level `main.yml`.

## Changes
- Added one canonical `.github/workflows/main.yml` workflow.
- Synchronized `.github/workflows/android-apk.yml` byte-for-byte with the canonical workflow.
- Added a regression test that fails if those two workflow files drift apart.
- Hardened ZIP discovery, version sorting, archive integrity checking, and path-traversal rejection before extraction.
- Added explicit source, SDK, generated web asset, APK integrity, and failure-diagnostic checks.
- No calculator UI or calculation-engine files were changed for this workflow-only repair.

## Local verification
- `npm test`: 151 passed, 0 failed.
- `npm run build:web`: passed; 8 required assets verified and copied.
- JavaScript syntax checks: passed for app, localization, currency names, theme bootstrap, server, service worker, and Android web preparation script.
- Both workflow YAML files parsed successfully.
- Workflow structural check: 19 steps and required build/test/artifact stages present.
- ZIP integrity and fresh extraction are verified after packaging.

## Not yet verified
This environment cannot execute a GitHub-hosted Actions runner or produce the final Android APK. Capacitor sync, Gradle compilation, APK verification, and artifact upload must still be confirmed by the next GitHub Actions run. A green local test suite does not guarantee a green remote Android build.
