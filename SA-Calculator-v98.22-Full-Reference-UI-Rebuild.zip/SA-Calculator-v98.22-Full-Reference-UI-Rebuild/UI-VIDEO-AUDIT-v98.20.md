# SA Calculator v98.20 — Recording-led UI correction

## Source material reviewed
- User reference image: dark navy native calculator layout with blue action keys, dark numeric keys, four-tab bottom navigation, grouped tool drawer, dedicated calculator tool pages and green result cards.
- User recording: `Screenrecording_20261116_142539.mp4`, 720×1560, 26.19 seconds. Nine sampled frames were reviewed at 1, 4, 7, 10, 13, 16, 19, 22 and 25 seconds.
- Source: complete v98.19.1 CI stale-source-fix ZIP.

## Confirmed defects in the recorded APK
1. A focused skip-to-content link rendered as a clipped cyan capsule over the top toolbar on Android.
2. Calculator header showed extra FX and history icons and an oversized/partially obstructed brand area instead of the reference's compact title and settings action.
3. Main keypad operators and equals button were constrained to small fixed widths instead of filling their grid cells; equals appeared as a narrow vertical pill.
4. The clear key label was visually missing, and the keypad did not provide the reference's +/- key.
5. The main display consumed too much vertical space; keypad and navigation proportions were unlike the reference.
6. Tool screens retained the global app header above their own title header, creating a duplicate/stacked toolbar.
7. Drawer was a long flat list with large rows rather than the reference's compact grouped categories.
8. Advanced functions/history/memory need to remain reachable while the primary keypad stays visually simple.

## v98.20 changes
- Rebuilt the calculator keypad order to AC, +/−, %, ÷ / 7–9, × / 4–6, − / 1–3, + / 0 spanning two columns, decimal and equals.
- Added a sign-toggle action that edits the current operand and handles committed results.
- Corrected all key cells to stretch across their full grid tracks; removed the fixed narrow operator/equal sizing.
- Moved scientific/history actions into the compact calculator utility strip and memory/parentheses/00 into the scientific panel so no existing capability is intentionally removed.
- Corrected the skip-link touch-focus overlay, compacted the header and display, and reduced bottom navigation height.
- Added a single back/title/more toolbar for each non-calculator destination and hid the duplicated global toolbar while inside tools.
- Reorganized the drawer into the reference categories: Calculator Tools, Percentage & Tax, Date & Fuel, Academic & Numbers, Finance.
- Standardized form fields, blue actions and green result panels across tool screens.
- Bumped app identity to `1.98.20-v98.20` and updated PWA theme colors.

## Verification limits
Local regression tests, JavaScript syntax, CSS parsing, HTML structure, YAML syntax and Android web bundle checks must pass before release. A new APK must then be built by GitHub Actions and tested on the user's Android phone. This source change alone cannot establish physical-device or universal bug-free status.

## Final local verification
- 172/172 regression tests pass.
- JavaScript syntax, CSS parsing, HTML ID uniqueness and both workflow YAML files pass.
- Android web bundle rebuilt successfully.
- Native version metadata is generated from package.json so this APK can upgrade over the previous release using a higher versionCode.
