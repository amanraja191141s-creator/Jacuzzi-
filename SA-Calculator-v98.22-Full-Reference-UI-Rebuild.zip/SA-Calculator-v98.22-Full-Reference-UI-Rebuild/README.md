# SA Calculator v98.21 — Reference UI and Android release

This release carries forward the v98.20 reference-led UI rebuild and hardens Android WebView touch focus so the accessibility skip link cannot cover the app toolbar on touch devices.

- App version: `1.98.21-v98.21`
- Android versionCode: `1098021`
- UI: midnight navy surfaces, electric-blue action keys, reference-order calculator keypad, grouped 18-tool drawer, dedicated tool pages, green calculation-result cards, four-tab bottom navigation.
- Cache identity: `sa-calculator-v98-21-native-dark-reference`
- All calculator tools and existing scientific, history, memory, currency and settings functions are retained.

## Build

Run `npm install`, `npm test`, `npm run build:web`, then `npx cap sync android` and `npm run android:brand`. Build the debug APK with `cd android && ./gradlew --no-daemon assembleDebug`.

The supplied GitHub Actions workflow requires the exact `1.98.21-v98.21` source version, runs regression checks, builds the APK, verifies the embedded Android versionName/versionCode, and uploads a version-labelled artifact.

A passing automated build does not prove physical-device rendering. Install the artifact labelled `SA-Calculator-Debug-APK-1.98.21-v98.21`, open Settings → About & Support, and confirm it displays `v1.98.21-v98.21` before comparing the UI.
